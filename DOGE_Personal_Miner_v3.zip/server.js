const http=require("http"),fs=require("fs"),path=require("path"),crypto=require("crypto"),{exec}=require("child_process");
const PORT=+process.env.PORT||8787, PUB=process.env.OFFERWALL_PUBLIC_KEY||"", SEC=process.env.OFFERWALL_SECRET||"";
const UNIT=+process.env.UNITS_PER_USD||100, RESERVE=+process.env.MINING_RESERVE_USD||1, COST=+process.env.COST_USD_PER_GHS_HOUR||.001;
const START=process.env.MINER_START_COMMAND||"", STOP=process.env.MINER_STOP_COMMAND||"", DATA=path.join(__dirname,"data.json");
const load=()=>fs.existsSync(DATA)?JSON.parse(fs.readFileSync(DATA)):({revenue:0,units:0,tx:{},mining:false,log:[]});
const save=s=>fs.writeFileSync(DATA,JSON.stringify(s,null,2));
const eq=(a,b)=>{a=Buffer.from(String(a));b=Buffer.from(String(b));return a.length===b.length&&crypto.timingSafeEqual(a,b)};
const sig=(u,t,a)=>crypto.createHmac("sha256",SEC).update(`${u}:${t}:${a}`).digest("hex");
const json=(r,c,x)=>{r.writeHead(c,{"Content-Type":"application/json","Cache-Control":"no-store"});r.end(JSON.stringify(x))};
const read=req=>new Promise((ok,no)=>{let b="";req.on("data",x=>b+=x);req.on("end",()=>ok(b));req.on("error",no)});
function calc(s){let spend=Math.max(0,s.revenue-RESERVE);return{spendableUsd:spend,maxGhsForOneHour:COST?Math.floor(spend/COST*1000)/1000:0}};
function mining(s,on){if(s.mining===on)return;s.mining=on;s.log.push({time:new Date().toISOString(),event:on?"START":"STOP"});save(s);const c=on?START:STOP;if(c)exec(c,{timeout:15000},()=>{})}
const server=http.createServer(async(req,res)=>{
 try{
  const u=new URL(req.url,`http://${req.headers.host}`);
  if(req.method==="GET"&&u.pathname==="/"){res.writeHead(200,{"Content-Type":"text/html"});return res.end(fs.readFileSync(path.join(__dirname,"public","index.html")))}
  if(req.method==="GET"&&u.pathname==="/api/config")return json(res,200,{publicKey:PUB,wallet:process.env.DOGE_WALLET||"",pool:process.env.DOGE_POOL||"",unit:UNIT,cost:COST,reserve:RESERVE});
  if(req.method==="GET"&&u.pathname==="/api/state"){let s=load();return json(res,200,{...s,calc:calc(s)})}
  if(req.method==="POST"&&u.pathname==="/api/mining"){let s=load(),p=JSON.parse(await read(req)||"{}");if(p.enabled&&!calc(s).spendableUsd)return json(res,409,{error:"No hay presupuesto disponible"});mining(s,!!p.enabled);save(s);return json(res,200,{ok:true})}
  if(req.method==="POST"&&u.pathname==="/offerwall/callback"){
   const b=await read(req),q=new URLSearchParams(b); // Offerwall can POST form-urlencoded
   const user=q.get("userId")||q.get("user")||q.get("user_id")||"",tx=q.get("transactionId")||q.get("tx")||q.get("txid")||"";
   const amount=q.get("currencyAmount")||q.get("amount")||"",signature=q.get("signature")||q.get("sig")||"";
   if(!SEC||!user||!tx||amount===""||!eq(sig(user,tx,amount),signature))return json(res,403,{error:"FORBIDDEN"});
   if(q.get("test")==="1")return json(res,200,{ok:true,test:true});
   const status=q.get("status")||"credited",s=load(),n=Number(amount);
   if(!Number.isFinite(n)||!["credited","reversed"].includes(status))return json(res,400,{error:"Invalid callback"});
   const key=tx+":"+status;if(s.tx[key])return json(res,200,{ok:true,duplicate:true});
   const payout=Number(q.get("payoutUsd")||0);
   // payoutUsd is NOT signed. Store it only for reconciliation; revenue is adjusted by it.
   s.revenue+=payout;s.units+=n;
   s.tx[key]={tx,user,amount:n,status,payoutUsd:payout,time:new Date().toISOString()};
   s.log.push({time:new Date().toISOString(),event:"CONVERSION",tx,status,units:n,payoutUsd:payout});
   save(s);return json(res,200,{ok:true});
  }
  return json(res,404,{error:"Not found"});
 }catch(e){return json(res,500,{error:"Server error"})}
});
server.listen(PORT,()=>console.log(`http://localhost:${PORT}`));
